import { createContext, useEffect, useMemo, useState } from "react";
import { Link } from 'react-router-dom';

import PropTypes from "prop-types";

export const PizzaContext = createContext();

const PizzaProvider = ({ children }) => {
  const [pizzas, setPizzas] = useState([]);
  const [cart, setCart] = useState([]);

  // Obtener datos
  const getData = async () => {
    const response = await fetch("/pizza.json");
    const pizzasData = await response.json();
    setPizzas(pizzasData);
  };

  useEffect(() => {
    getData();
  }, []);

  const addToCart = (pizza) => {
    setCart([...cart, pizza]);
  };

  const removeFromCart = (pizzaId) => {
    setCart(cart.filter(pizza => pizza.id !== pizzaId));
  };

  const updateQuantity = (pizzaId, newQuantity) => {
    setCart(cart.map(pizza => pizza.id === pizzaId ? { ...pizza, quantity: newQuantity } : pizza));
  };

  const pizzaContextValue = useMemo(() => ({ pizzas, cart, addToCart, removeFromCart, updateQuantity }), [pizzas, cart, addToCart, removeFromCart, updateQuantity]); // Agregar las funciones al arreglo de dependencias

  return (
    <PizzaContext.Provider value={pizzaContextValue}>
      {children}
    </PizzaContext.Provider>
  );
};

PizzaProvider.propTypes = {
  children: PropTypes.node.isRequired,
};

export default PizzaProvider;


