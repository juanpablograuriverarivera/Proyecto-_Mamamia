import { useContext } from 'react';
import { PizzaContext } from '../context/PizzaProvider';

const Cart = () => {
  const { cart, removeFromCart, updateQuantity } = useContext(PizzaContext);

  // Calcular el total del carrito
  const total = cart.reduce((acc, pizza) => acc + pizza.price * pizza.quantity, 0);

  return (
    <div>
      <h2>Carrito</h2>
      {cart.length === 0 ? (
        <p>No hay pizzas en el carrito</p>
      ) : (
        <>
          {cart.map((pizza) => (
            <div key={pizza.id}>
              <img src={pizza.img} alt={pizza.name} style={{ width: '100px' }} />
              <div>
                <h3>{pizza.name}</h3>
                <p>Precio: ${pizza.price}</p>
                <p>Cantidad: {pizza.quantity}</p>
                <button onClick={() => updateQuantity(pizza.id, pizza.quantity - 1)}>-</button>
                <button onClick={() => updateQuantity(pizza.id, pizza.quantity + 1)}>+</button>
                <button onClick={() => removeFromCart(pizza.id)}>Eliminar</button>
              </div>
            </div>
          ))}
          <p>Total: ${total.toFixed(2)}</p>
          <button>Ir a pagar</button>
        </>
      )}
    </div>
  );
}

export default Cart;




