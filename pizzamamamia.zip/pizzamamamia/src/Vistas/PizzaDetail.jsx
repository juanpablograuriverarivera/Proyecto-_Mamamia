import { useContext } from 'react';
import { useParams } from 'react-router-dom';
import { PizzaContext } from '../context/PizzaProvider';

const PizzaDetail = () => {
  const { pizzas } = useContext(PizzaContext);
  const { id } = useParams();
  const pizza = pizzas.find(pizza => pizza.id === id);

  if (!pizza) return <div>Pizza no encontrada</div>;

  return (
    <div className="card">
      <div className="row g-0">
        <div className="col-md-6">
          <img src={pizza.img} className="img-fluid rounded-start" alt={pizza.name} />
        </div>
        <div className="col-md-6">
          <div className="card-body">
            <h5 className="card-title">{pizza.name}</h5>
            <p className="card-text">{pizza.desc}</p>
            <p className="card-text">Precio: ${pizza.price}</p>
            <p className="card-text">Ingredientes: {pizza.ingredients.join(', ')}</p>
            <button className="btn btn-primary">Añadir al Carrito</button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default PizzaDetail;
