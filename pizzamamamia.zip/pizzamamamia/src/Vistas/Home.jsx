// Home.jsx

import { useContext, useState } from 'react';
import { Link } from 'react-router-dom';
import { PizzaContext } from '../context/PizzaProvider';

const Home = () => {
  const { pizzas } = useContext(PizzaContext);
  const [cart, setCart] = useState([]);

  const addToCart = (pizza) => {
    setCart([...cart, pizza]);
  };

  return (
    <div className="container">
      <div className="row">
        {pizzas &&
          pizzas.map((pizza) => (
            <div key={pizza.id} className="col-md-4">
              <div className="card">
                <img src={pizza.img} className="card-img-top" alt="Pizza" />
                <div className="card-body">
                  <h5 className="card-title">{pizza.name}</h5>
                  <p className="card-text">Ingredientes: {pizza.ingredients.join(', ')}</p>
                  <p className="card-text">Precio: ${pizza.price}</p>
                  <div className="d-flex justify-content-between">
                    <Link to="/cart" className="btn btn-primary" onClick={() => addToCart(pizza)}>
                      Añadir al carrito
                    </Link>
                    <Link to={`/pizza/${pizza.id}`} className="btn btn-primary">
                      Ver más
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          ))}
      </div>
    </div>
  );
};

export default Home;





